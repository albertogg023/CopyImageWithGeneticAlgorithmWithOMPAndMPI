convert -compress none -resize 512x512 $1 $2
