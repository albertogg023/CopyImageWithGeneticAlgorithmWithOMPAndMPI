convert -compress none -resize 1024x1024 $1 $2
